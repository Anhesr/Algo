#ifndef BACKTRACKING_HPP
#define BACKTRACKING_HPP

#include <vector>
#include <iostream>
#include <cmath>

using namespace std;

bool lugar(int k ,vector <int> x);

void reinas(int n,vector < vector <int> > &Mat);

void lasVegas(int n , vector <int> x,bool &exito);
#endif

